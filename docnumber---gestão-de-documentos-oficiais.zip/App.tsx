
import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, Navigate, Link, useNavigate, useLocation } from 'react-router-dom';
import { User, UserRole, DocumentRecord, DocumentTypeConfig } from './types';
import { dbService } from './services/dbService';

// Pages
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import FormDocumento from './pages/FormDocumento';
import Historico from './pages/Historico';
import Configuracoes from './pages/Configuracoes';
import Admin from './pages/Admin';
import Usuarios from './pages/Usuarios';

const Sidebar = ({ user, logout }: { user: User, logout: () => void }) => {
  const location = useLocation();
  const isAdmin = user.perfil === UserRole.ADMIN;

  const NavItem = ({ to, icon, label }: { to: string, icon: string, label: string }) => {
    const active = location.pathname === to;
    return (
      <Link 
        to={to} 
        className={`flex items-center space-x-3 px-4 py-3 rounded-lg transition-colors ${
          active ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-800 hover:text-white'
        }`}
      >
        <i className={`fas ${icon} w-5`}></i>
        <span className="font-medium">{label}</span>
      </Link>
    );
  };

  return (
    <div className="w-64 bg-slate-900 h-screen fixed left-0 top-0 text-white flex flex-col z-50">
      <div className="p-6 border-b border-slate-800">
        <h1 className="text-xl font-bold flex items-center gap-2">
          <i className="fas fa-file-invoice text-blue-500"></i>
          DocNumber
        </h1>
        <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest font-semibold">GMNL Management</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
        <NavItem to="/dashboard" icon="fa-th-large" label="Início" />
        <NavItem to="/historico" icon="fa-history" label="Meu Histórico" />
        
        {isAdmin && (
          <div className="pt-4 mt-4 border-t border-slate-800">
            <p className="px-4 text-[10px] uppercase text-slate-500 font-bold mb-2 tracking-wider">Gestão</p>
            <NavItem to="/admin" icon="fa-chart-pie" label="Administração" />
            <NavItem to="/usuarios" icon="fa-users" label="Usuários" />
            <NavItem to="/configuracoes" icon="fa-cog" label="Configurações" />
          </div>
        )}
      </nav>

      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center space-x-3 mb-4 px-2">
          <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
            {user.nome.charAt(0)}
          </div>
          <div className="flex-1 overflow-hidden">
            <p className="text-sm font-semibold truncate">{user.nome}</p>
            <p className="text-xs text-slate-500 truncate">{user.perfil === UserRole.ADMIN ? 'Admin' : 'Membro'}</p>
          </div>
        </div>
        <button 
          onClick={logout}
          className="w-full flex items-center justify-center space-x-2 px-4 py-2 bg-slate-800 hover:bg-red-900/40 hover:text-red-400 text-slate-300 rounded-lg transition-all"
        >
          <i className="fas fa-sign-out-alt"></i>
          <span>Sair</span>
        </button>
      </div>
    </div>
  );
};

interface ProtectedRouteProps {
  children: React.ReactNode;
  user: User | null;
}

const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, user }) => {
  if (!user) return <Navigate to="/login" replace />;
  return <>{children}</>;
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);

  const login = (user: User) => setCurrentUser(user);
  const logout = () => setCurrentUser(null);

  return (
    <HashRouter>
      <div className="min-h-screen bg-slate-50">
        {currentUser && <Sidebar user={currentUser} logout={logout} />}
        <main className={`${currentUser ? 'ml-64' : ''} transition-all`}>
          <Routes>
            <Route path="/login" element={currentUser ? <Navigate to="/dashboard" /> : <Login onLogin={login} />} />
            
            <Route path="/dashboard" element={
              <ProtectedRoute user={currentUser}>
                <Dashboard user={currentUser!} />
              </ProtectedRoute>
            } />

            <Route path="/documento/:id" element={
              <ProtectedRoute user={currentUser}>
                <FormDocumento />
              </ProtectedRoute>
            } />

            <Route path="/historico" element={
              <ProtectedRoute user={currentUser}>
                <Historico user={currentUser!} />
              </ProtectedRoute>
            } />

            <Route path="/usuarios" element={
              <ProtectedRoute user={currentUser}>
                {currentUser?.perfil === UserRole.ADMIN ? <Usuarios /> : <Navigate to="/dashboard" />}
              </ProtectedRoute>
            } />

            <Route path="/configuracoes" element={
              <ProtectedRoute user={currentUser}>
                {currentUser?.perfil === UserRole.ADMIN ? <Configuracoes /> : <Navigate to="/dashboard" />}
              </ProtectedRoute>
            } />

            <Route path="/admin" element={
              <ProtectedRoute user={currentUser}>
                {currentUser?.perfil === UserRole.ADMIN ? <Admin /> : <Navigate to="/dashboard" />}
              </ProtectedRoute>
            } />

            <Route path="*" element={<Navigate to="/dashboard" replace />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
};

export default App;
