
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { DocumentRecord, DocumentStatus, DocumentTypeConfig, User } from '../types';
import { dbService } from '../services/dbService';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie } from 'recharts';

const Admin: React.FC = () => {
  const navigate = useNavigate();
  const [allDocs, setAllDocs] = useState<DocumentRecord[]>([]);
  const [types, setTypes] = useState<DocumentTypeConfig[]>([]);
  const [users, setUsers] = useState<User[]>([]);

  // Filters
  const [filterUser, setFilterUser] = useState('');
  const [filterType, setFilterType] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  useEffect(() => {
    setAllDocs(dbService.getDocuments());
    setTypes(dbService.getDocumentTypes());
    setUsers(dbService.getUsers());
  }, []);

  const filteredDocs = allDocs.filter(d => {
    const matchUser = !filterUser || d.usuarioId === filterUser;
    const matchType = !filterType || d.tipo === filterType;
    const matchStatus = !filterStatus || d.status === filterStatus;
    return matchUser && matchType && matchStatus;
  }).reverse();

  // Stats for charts
  const typeStats = types.map(t => ({
    name: t.sigla,
    total: allDocs.filter(d => d.tipo === t.sigla).length,
    color: '#3b82f6'
  }));

  const userStats = users.map(u => ({
    name: u.nome.split(' ')[0],
    total: allDocs.filter(d => d.usuarioId === u.id).length
  }));

  const statusStats = [
    { name: 'Lançados', value: allDocs.filter(d => d.status === DocumentStatus.LANCADO).length, color: '#22c55e' },
    { name: 'Reservados', value: allDocs.filter(d => d.status === DocumentStatus.RESERVADO).length, color: '#f59e0b' },
  ];

  const COLORS = ['#22c55e', '#f59e0b'];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900">Visão Administrativa</h2>
          <p className="text-slate-500 mt-1">Monitore toda a numeração corporativa e auditagem do sistema.</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => navigate('/usuarios')}
            className="bg-white border-2 border-slate-200 hover:border-blue-500 hover:text-blue-600 text-slate-700 font-bold py-3 px-6 rounded-xl transition-all flex items-center gap-2 shadow-sm"
          >
            <i className="fas fa-user-gear"></i> Gerenciar Usuários
          </button>
        </div>
      </header>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        {[
          { label: 'Total Documentos', value: allDocs.length, icon: 'fa-file-alt', color: 'blue' },
          { label: 'Lançados', value: allDocs.filter(d => d.status === DocumentStatus.LANCADO).length, icon: 'fa-check-circle', color: 'green' },
          { label: 'Reservas Ativas', value: allDocs.filter(d => d.status === DocumentStatus.RESERVADO).length, icon: 'fa-clock', color: 'amber' },
          { label: 'Tipos Configurados', value: types.length, icon: 'fa-cog', color: 'slate' },
        ].map((stat, i) => (
          <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
            <div className={`w-12 h-12 rounded-xl bg-${stat.color}-50 text-${stat.color}-600 flex items-center justify-center mb-4`}>
              <i className={`fas ${stat.icon} text-xl`}></i>
            </div>
            <p className="text-slate-400 text-xs font-bold uppercase tracking-wider">{stat.label}</p>
            <p className="text-3xl font-black text-slate-900">{stat.value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
        <div className="lg:col-span-2 bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-800 mb-6">Documentos por Tipo</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={typeStats}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip 
                  cursor={{fill: '#f1f5f9'}}
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                />
                <Bar dataKey="total" fill="#3b82f6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
          <h3 className="font-bold text-slate-800 mb-6">Distribuição de Status</h3>
          <div className="h-64 flex flex-col items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={statusStats}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {statusStats.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex gap-4 mt-2">
              {statusStats.map((s, i) => (
                <div key={i} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{backgroundColor: s.color}}></div>
                  <span className="text-xs font-bold text-slate-600">{s.name}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Main Table with Filters */}
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex flex-wrap gap-4">
          <select 
            value={filterUser}
            onChange={e => setFilterUser(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Todos Usuários</option>
            {users.map(u => <option key={u.id} value={u.id}>{u.nome}</option>)}
          </select>

          <select 
            value={filterType}
            onChange={e => setFilterType(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Todos Tipos</option>
            {types.map(t => <option key={t.id} value={t.sigla}>{t.sigla}</option>)}
          </select>

          <select 
            value={filterStatus}
            onChange={e => setFilterStatus(e.target.value)}
            className="p-2 bg-slate-50 border border-slate-300 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="">Todos Status</option>
            {Object.values(DocumentStatus).map(s => <option key={s} value={s}>{s}</option>)}
          </select>

          <div className="ml-auto text-xs text-slate-400 font-bold uppercase py-2">
            Mostrando {filteredDocs.length} registros
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-slate-50 text-slate-500 text-[10px] font-bold uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4">Documento</th>
                <th className="px-6 py-4">Usuário</th>
                <th className="px-6 py-4">Assunto</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Criado em</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocs.map(doc => (
                <tr key={doc.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-4 font-bold text-slate-900">{doc.codigoCompleto}</td>
                  <td className="px-6 py-4 text-sm text-slate-600">{doc.usuarioNome}</td>
                  <td className="px-6 py-4 max-w-xs text-sm text-slate-600 truncate">{doc.demandaSolicitante || '(Reservado)'}</td>
                  <td className="px-6 py-4">
                    <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                      doc.status === DocumentStatus.LANCADO ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                    }`}>
                      {doc.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-xs text-slate-500">
                    {new Date(doc.createdAt).toLocaleString('pt-BR')}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Admin;
