
import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { User, DocumentTypeConfig, DocumentRecord, DocumentStatus, UserRole } from '../types';
import { dbService } from '../services/dbService';

const Dashboard: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();
  const [types, setTypes] = useState<DocumentTypeConfig[]>([]);
  const [selectedTypeId, setSelectedTypeId] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [recentDocs, setRecentDocs] = useState<DocumentRecord[]>([]);

  const refreshData = useCallback(() => {
    setTypes(dbService.getDocumentTypes());
    const allDocs = dbService.getDocuments();
    setRecentDocs(allDocs.filter(d => d.usuarioId === user.id).slice(-3).reverse());
  }, [user.id]);

  useEffect(() => {
    refreshData();
    window.addEventListener('db_updated', refreshData);
    const handleStorage = (e: StorageEvent) => {
      if (e.key === 'docnumber_db') refreshData();
    };
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('db_updated', refreshData);
      window.removeEventListener('storage', handleStorage);
    };
  }, [refreshData]);

  const handleGenerate = () => {
    if (!selectedTypeId) return;
    setIsGenerating(true);
    setTimeout(() => {
      try {
        const newDoc = dbService.reserveNumber(selectedTypeId, user);
        navigate(`/documento/${newDoc.id}`);
      } catch (err) {
        alert("Erro ao gerar número: " + (err as Error).message);
        refreshData();
      } finally {
        setIsGenerating(false);
      }
    }, 600);
  };

  const selectedType = types.find(t => t.id === selectedTypeId);
  const isAdmin = user.perfil === UserRole.ADMIN;

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <header className="mb-10 flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900">Bom dia, {user.nome.split(' ')[0]}!</h2>
          <p className="text-slate-500 mt-1 font-medium">Gere novos números ou acompanhe seus lançamentos recentes.</p>
        </div>

        {/* Botões de Gestão Rápida para Admin */}
        {isAdmin && (
          <div className="flex gap-3 bg-white p-2 rounded-2xl shadow-sm border border-slate-200">
            <button 
              onClick={() => navigate('/usuarios')}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-sm font-bold flex items-center gap-2 transition-all shadow-lg shadow-blue-500/20"
            >
              <i className="fas fa-users-cog"></i> Gerenciar Usuários
            </button>
            <button 
              onClick={() => navigate('/admin')}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-sm font-bold flex items-center gap-2 transition-all"
            >
              <i className="fas fa-chart-pie"></i> Painel Admin
            </button>
          </div>
        )}
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="font-bold text-slate-800 flex items-center gap-2">
                <i className="fas fa-plus-circle text-blue-600"></i>
                Reservar Nova Numeração
              </h3>
              <span className="text-[10px] font-bold bg-blue-100 text-blue-700 px-2 py-1 rounded-md uppercase tracking-tighter">
                Sincronizado em tempo real
              </span>
            </div>
            <div className="p-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-600">Tipo de Documento</label>
                  <select 
                    value={selectedTypeId}
                    onChange={(e) => setSelectedTypeId(e.target.value)}
                    className="w-full p-3 border border-slate-300 rounded-xl bg-white focus:ring-2 focus:ring-blue-500 outline-none transition-all"
                  >
                    <option value="">Selecione um tipo...</option>
                    {types.map(t => (
                      <option key={t.id} value={t.id}>{t.sigla} - {t.descricao}</option>
                    ))}
                  </select>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-600">Ano</label>
                  <input 
                    type="text" 
                    readOnly 
                    value={new Date().getFullYear()} 
                    className="w-full p-3 border border-slate-200 rounded-xl bg-slate-100 text-slate-500 font-medium cursor-not-allowed" 
                  />
                </div>
              </div>

              {selectedType && (
                <div className="mt-8 p-6 bg-blue-50 rounded-2xl border border-blue-100 flex flex-col md:flex-row items-center justify-between gap-4 animate-fadeIn">
                  <div>
                    <span className="text-xs font-bold text-blue-600 uppercase tracking-widest flex items-center gap-1">
                      <span className="relative flex h-2 w-2">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                      </span>
                      Próximo disponível agora
                    </span>
                    <p className="text-3xl font-black text-slate-800">
                      {selectedType.sigla} {selectedType.prefixo} {selectedType.contadorAtual.toString().padStart(3, '0')}/{new Date().getFullYear()}
                    </p>
                  </div>
                  <button 
                    onClick={handleGenerate}
                    disabled={isGenerating}
                    className="w-full md:w-auto px-8 py-4 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-400 text-white font-bold rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center justify-center gap-2"
                  >
                    {isGenerating ? (
                      <>
                        <i className="fas fa-lock animate-pulse"></i>
                        Reservando...
                      </>
                    ) : (
                      <>
                        <i className="fas fa-check-circle"></i>
                        Gerar e Reservar Número
                      </>
                    )}
                  </button>
                </div>
              )}
            </div>
          </div>
          
          {/* Alerta Ampliado e com Muito Mais Destaque */}
          <div className="mt-8 p-1 bg-gradient-to-r from-amber-400 to-orange-500 rounded-[22px] shadow-xl shadow-amber-500/10 transition-transform hover:scale-[1.01]">
            <div className="bg-amber-50 rounded-2xl p-8 flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="w-20 h-20 bg-amber-500 rounded-2xl flex items-center justify-center shrink-0 shadow-lg shadow-amber-500/30 border-4 border-white">
                <i className="fas fa-shield-halved text-white text-4xl"></i>
              </div>
              <div>
                <h4 className="text-amber-900 font-black text-2xl mb-2 uppercase tracking-tight flex items-center gap-2">
                  Segurança na Numeração
                  <span className="inline-block px-2 py-1 bg-amber-200 text-amber-800 text-[10px] rounded-md animate-pulse">SISTEMA ATIVO</span>
                </h4>
                <p className="text-amber-800 text-lg leading-snug font-semibold italic">
                  "O número é seu no momento do clique."
                </p>
                <p className="mt-2 text-amber-700 text-sm md:text-base leading-relaxed">
                  Ao clicar em <strong>"Gerar e Reservar"</strong>, o sistema bloqueia esta numeração instantaneamente para seu usuário. 
                  Isso evita qualquer risco de duplicidade, mesmo que múltiplas pessoas estejam tentando gerar o mesmo tipo de documento ao mesmo tempo em diferentes setores da empresa.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6">
            <h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2">
              <i className="fas fa-clock text-blue-500"></i>
              Meus Recentes
            </h3>
            {recentDocs.length > 0 ? (
              <div className="space-y-4">
                {recentDocs.map(doc => (
                  <div key={doc.id} className="p-3 bg-slate-50 rounded-xl border border-slate-100 hover:border-blue-200 transition-colors cursor-pointer" onClick={() => navigate(`/documento/${doc.id}`)}>
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-xs font-bold text-blue-600">{doc.codigoCompleto}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        doc.status === DocumentStatus.LANCADO ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {doc.status}
                      </span>
                    </div>
                    <p className="text-sm text-slate-700 truncate font-medium">
                      {doc.demandaSolicitante || '(Aguardando preenchimento)'}
                    </p>
                  </div>
                ))}
                <button 
                  onClick={() => navigate('/historico')}
                  className="w-full py-2 text-sm text-blue-600 font-bold hover:text-blue-800 transition-colors"
                >
                  Ver todo histórico
                </button>
              </div>
            ) : (
              <div className="py-8 text-center">
                <p className="text-slate-400 text-sm">Nenhum documento gerado.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
