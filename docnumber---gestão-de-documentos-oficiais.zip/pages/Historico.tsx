
import React, { useState, useEffect } from 'react';
import { User, DocumentRecord, DocumentStatus } from '../types';
import { dbService } from '../services/dbService';
import { useNavigate } from 'react-router-dom';

const Historico: React.FC<{ user: User }> = ({ user }) => {
  const navigate = useNavigate();
  const [docs, setDocs] = useState<DocumentRecord[]>([]);
  const [filter, setFilter] = useState('');

  useEffect(() => {
    const all = dbService.getDocuments();
    setDocs(all.filter(d => d.usuarioId === user.id).reverse());
  }, [user.id]);

  const openAnexo = (anexoData: string) => {
    const win = window.open();
    if (win) {
      win.document.write(`<iframe src="${anexoData}" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>`);
    }
  };

  const filteredDocs = docs.filter(d => 
    d.codigoCompleto.toLowerCase().includes(filter.toLowerCase()) ||
    d.demandaSolicitante.toLowerCase().includes(filter.toLowerCase()) ||
    d.destinatario.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <header className="mb-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900">Meu Histórico</h2>
          <p className="text-slate-500 mt-1">Todos os documentos gerados por você.</p>
        </div>
        <div className="relative">
          <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400">
            <i className="fas fa-search"></i>
          </span>
          <input 
            type="text" 
            placeholder="Buscar por número ou assunto..."
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="pl-10 pr-4 py-2 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none w-full md:w-64 transition-all"
          />
        </div>
      </header>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-500 text-xs font-bold uppercase tracking-wider">
                <th className="px-6 py-4">Documento</th>
                <th className="px-6 py-4">Assunto</th>
                <th className="px-6 py-4">Destinatário</th>
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredDocs.length > 0 ? (
                filteredDocs.map(doc => (
                  <tr key={doc.id} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4">
                      <span className="font-bold text-slate-900">{doc.codigoCompleto}</span>
                    </td>
                    <td className="px-6 py-4 max-w-xs">
                      <p className="text-sm text-slate-600 truncate">{doc.demandaSolicitante || '(Sem descrição)'}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-slate-600">{doc.destinatario || '-'}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm text-slate-500">{new Date(doc.dataEnvio).toLocaleDateString('pt-BR')}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${
                        doc.status === DocumentStatus.LANCADO ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
                      }`}>
                        {doc.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button 
                          onClick={() => navigate(`/documento/${doc.id}`)}
                          className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
                          title="Ver Detalhes"
                        >
                          <i className="fas fa-eye"></i>
                        </button>
                        {doc.anexos && doc.anexos.length > 0 && (
                          <button 
                            onClick={() => openAnexo(doc.anexos[0])}
                            className="p-2 text-blue-400 hover:text-blue-600 rounded-lg transition-all"
                            title="Visualizar Primeiro Anexo"
                          >
                            <i className="fas fa-file-download"></i>
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={6} className="px-6 py-20 text-center">
                    <div className="text-slate-300 mb-3">
                      <i className="fas fa-folder-open text-5xl"></i>
                    </div>
                    <p className="text-slate-500 font-medium">Nenhum documento encontrado.</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Historico;
