
import React, { useState, useEffect } from 'react';
import { DocumentTypeConfig } from '../types';
import { dbService } from '../services/dbService';

const Configuracoes: React.FC = () => {
  const [types, setTypes] = useState<DocumentTypeConfig[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingType, setEditingType] = useState<DocumentTypeConfig | null>(null);

  // Form State
  const [sigla, setSigla] = useState('');
  const [descricao, setDescricao] = useState('');
  const [prefixo, setPrefixo] = useState('');
  const [contador, setContador] = useState(1);
  const [reset, setReset] = useState(true);

  useEffect(() => {
    setTypes(dbService.getDocumentTypes());
  }, []);

  const resetForm = () => {
    setSigla('');
    setDescricao('');
    setPrefixo('');
    setContador(1);
    setReset(true);
    setEditingType(null);
  };

  const handleEdit = (type: DocumentTypeConfig) => {
    setEditingType(type);
    setSigla(type.sigla);
    setDescricao(type.descricao);
    setPrefixo(type.prefixo);
    setContador(type.contadorAtual);
    setReset(type.resetAnual);
    setShowModal(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingType) {
      dbService.updateDocumentType(editingType.id, {
        sigla, descricao, prefixo, contadorAtual: contador, resetAnual: reset
      });
    } else {
      dbService.addDocumentType({
        sigla, descricao, prefixo, contadorAtual: contador, resetAnual: reset
      });
    }
    setTypes(dbService.getDocumentTypes());
    setShowModal(false);
    resetForm();
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <header className="mb-10 flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-extrabold text-slate-900">Tipos de Documentos</h2>
          <p className="text-slate-500 mt-1">Configure as siglas e regras de numeração do sistema.</p>
        </div>
        <button 
          onClick={() => { resetForm(); setShowModal(true); }}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-xl shadow-lg shadow-blue-500/20 transition-all flex items-center gap-2"
        >
          <i className="fas fa-plus"></i> Novo Tipo
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {types.map(type => (
          <div key={type.id} className="bg-white rounded-2xl shadow-sm border border-slate-200 p-6 hover:border-blue-300 transition-all group">
            <div className="flex justify-between items-start mb-4">
              <div className="w-12 h-12 bg-blue-50 rounded-xl flex items-center justify-center text-blue-600 font-black text-xl">
                {type.sigla}
              </div>
              <button 
                onClick={() => handleEdit(type)}
                className="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-all"
              >
                <i className="fas fa-edit"></i>
              </button>
            </div>
            <h3 className="font-bold text-slate-900 text-lg">{type.descricao}</h3>
            <p className="text-slate-500 text-sm mb-4">Prefixo: <span className="font-mono bg-slate-100 px-2 rounded">{type.prefixo}</span></p>
            
            <div className="flex items-center justify-between pt-4 border-t border-slate-100">
              <div className="text-xs">
                <p className="text-slate-400 font-bold uppercase">Contador Atual</p>
                <p className="text-xl font-black text-slate-800">{type.contadorAtual.toString().padStart(3, '0')}</p>
              </div>
              <div className="text-right text-xs">
                <p className="text-slate-400 font-bold uppercase">Reset Anual</p>
                <p className={`font-bold ${type.resetAnual ? 'text-green-600' : 'text-amber-600'}`}>
                  {type.resetAnual ? 'Habilitado' : 'Desabilitado'}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
          <div className="bg-white rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden animate-scaleIn">
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex justify-between items-center">
              <h3 className="text-xl font-bold text-slate-900">{editingType ? 'Editar Tipo' : 'Novo Tipo de Documento'}</h3>
              <button onClick={() => setShowModal(false)} className="text-slate-400 hover:text-slate-600">
                <i className="fas fa-times"></i>
              </button>
            </div>
            <form onSubmit={handleSave} className="p-8 space-y-6">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Sigla (ex: CE)</label>
                  <input required maxLength={4} value={sigla} onChange={e => setSigla(e.target.value.toUpperCase())} className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Prefixo (ex: GMNL)</label>
                  <input required maxLength={6} value={prefixo} onChange={e => setPrefixo(e.target.value.toUpperCase())} className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold text-slate-500 uppercase">Descrição Completa</label>
                <input required value={descricao} onChange={e => setDescricao(e.target.value)} className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" placeholder="Ex: Comunicação Externa" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1">
                  <label className="text-xs font-bold text-slate-500 uppercase">Próximo Número</label>
                  <input type="number" required min={1} value={contador} onChange={e => setContador(parseInt(e.target.value))} className="w-full p-3 border border-slate-300 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" />
                </div>
                <div className="flex items-center gap-3 pt-6">
                  <input type="checkbox" id="reset-anual" checked={reset} onChange={e => setReset(e.target.checked)} className="w-5 h-5 rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
                  <label htmlFor="reset-anual" className="text-sm font-bold text-slate-700">Resetar anualmente?</label>
                </div>
              </div>
              <div className="pt-4 flex gap-3">
                <button type="submit" className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-xl shadow-lg shadow-blue-500/20 transition-all">
                  Salvar Configuração
                </button>
                <button type="button" onClick={() => setShowModal(false)} className="px-6 py-3 border border-slate-300 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-all">
                  Cancelar
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Configuracoes;
