
import React, { useState, useEffect, useRef } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { dbService } from '../services/dbService';
import { DocumentRecord, DocumentStatus } from '../types';
import { summarizeDemand, suggestRecipientFormalGreeting } from '../services/geminiService';

const FormDocumento: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [doc, setDoc] = useState<DocumentRecord | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isAIThinking, setIsAIThinking] = useState(false);

  // Form states
  const [demanda, setDemanda] = useState('');
  const [impactado, setImpactado] = useState('');
  const [destinatario, setDestinatario] = useState('');
  const [dataEnvio, setDataEnvio] = useState(new Date().toISOString().split('T')[0]);
  const [anexos, setAnexos] = useState<string[]>([]);
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    if (id) {
      const record = dbService.getDocumentById(id);
      if (record) {
        setDoc(record);
        setDemanda(record.demandaSolicitante);
        setImpactado(record.impactado);
        setDestinatario(record.destinatario);
        setDataEnvio(record.dataEnvio);
        setAnexos(record.anexos || []);
      } else {
        navigate('/dashboard');
      }
    }
  }, [id, navigate]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsUploading(true);
    const newAnexos = [...anexos];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      // Limite de 2MB por arquivo para não estourar o localStorage rapidamente
      if (file.size > 2 * 1024 * 1024) {
        alert(`O arquivo ${file.name} excede o limite de 2MB.`);
        continue;
      }

      try {
        const base64 = await fileToBase64(file);
        newAnexos.push(base64);
      } catch (err) {
        console.error("Erro ao processar arquivo:", err);
      }
    }

    setAnexos(newAnexos);
    setIsUploading(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = error => reject(error);
    });
  };

  const removeAnexo = (index: number) => {
    setAnexos(anexos.filter((_, i) => i !== index));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!doc) return;

    setIsSaving(true);
    dbService.updateDocument(doc.id, {
      demandaSolicitante: demanda,
      impactado,
      destinatario,
      dataEnvio,
      anexos,
      status: DocumentStatus.LANCADO
    });
    
    setTimeout(() => {
      setIsSaving(false);
      navigate('/historico');
    }, 1000);
  };

  const handleAISuggest = async () => {
    if (!demanda) return;
    setIsAIThinking(true);
    try {
      const summary = await summarizeDemand(demanda);
      setDemanda(summary);
    } catch (err) {
      console.error(err);
    } finally {
      setIsAIThinking(false);
    }
  };

  if (!doc) return null;

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <div className="mb-6 flex items-center justify-between">
        <button 
          onClick={() => navigate('/dashboard')}
          className="text-slate-500 hover:text-slate-900 flex items-center gap-2 font-medium"
        >
          <i className="fas fa-arrow-left"></i> Voltar
        </button>
        <div className={`px-4 py-1 rounded-full text-xs font-bold uppercase ${
          doc.status === DocumentStatus.LANCADO ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'
        }`}>
          Status: {doc.status}
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 bg-slate-900 text-white flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <h2 className="text-2xl font-black">{doc.codigoCompleto}</h2>
            <p className="text-slate-400 text-sm">Número reservado em {new Date(doc.createdAt).toLocaleString()}</p>
          </div>
          <div className="flex items-center gap-4 text-sm text-slate-300">
            <div className="flex flex-col items-end">
              <span className="font-bold text-white uppercase text-[10px] tracking-widest opacity-50">Solicitante</span>
              <span>{doc.usuarioNome}</span>
            </div>
          </div>
        </div>

        <form onSubmit={handleSave} className="p-8 space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2 md:col-span-2">
              <div className="flex justify-between">
                <label className="text-sm font-bold text-slate-700">Demanda / Descrição da Solicitação</label>
                <button 
                  type="button"
                  onClick={handleAISuggest}
                  disabled={isAIThinking || !demanda}
                  className="text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1"
                >
                  {isAIThinking ? <i className="fas fa-sync fa-spin"></i> : <i className="fas fa-magic"></i>}
                  Sugerir Resumo com IA
                </button>
              </div>
              <textarea 
                rows={4}
                required
                value={demanda}
                onChange={(e) => setDemanda(e.target.value)}
                placeholder="Descreva detalhadamente o motivo da emissão deste documento..."
                className="w-full p-4 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none resize-none transition-all"
              ></textarea>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Setor/Pessoa Impactada</label>
              <input 
                type="text" 
                required
                value={impactado}
                onChange={(e) => setImpactado(e.target.value)}
                placeholder="Ex: Recursos Humanos"
                className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Destinatário</label>
              <input 
                type="text" 
                required
                value={destinatario}
                onChange={(e) => setDestinatario(e.target.value)}
                placeholder="Ex: Diretor Financeiro"
                className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-bold text-slate-700">Data de Envio</label>
              <input 
                type="date" 
                required
                value={dataEnvio}
                onChange={(e) => setDataEnvio(e.target.value)}
                className="w-full p-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none transition-all"
              />
            </div>

            <div className="space-y-4 md:col-span-2">
              <label className="text-sm font-bold text-slate-700">Anexos / Documentos (Máx 2MB por arquivo)</label>
              
              {/* Dropzone visual */}
              <div className="flex flex-col gap-4">
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 border-dashed rounded-xl cursor-pointer bg-slate-50 hover:bg-slate-100 transition-all">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    {isUploading ? (
                      <i className="fas fa-circle-notch fa-spin text-2xl text-blue-500 mb-2"></i>
                    ) : (
                      <i className="fas fa-cloud-upload-alt text-2xl text-slate-400 mb-2"></i>
                    )}
                    <p className="text-xs text-slate-500 font-medium">
                      {isUploading ? 'Processando arquivos...' : 'Clique para selecionar arquivos'}
                    </p>
                  </div>
                  <input 
                    type="file" 
                    ref={fileInputRef}
                    multiple
                    className="hidden" 
                    onChange={handleFileChange}
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                  />
                </label>

                {/* Lista de Arquivos Selecionados */}
                {anexos.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {anexos.map((fileData, idx) => (
                      <div key={idx} className="flex items-center justify-between p-3 bg-blue-50 border border-blue-100 rounded-xl">
                        <div className="flex items-center gap-2 overflow-hidden">
                          <i className="fas fa-file-alt text-blue-500"></i>
                          <span className="text-xs font-medium text-blue-700 truncate">Anexo {idx + 1}</span>
                        </div>
                        <button 
                          type="button" 
                          onClick={() => removeAnexo(idx)}
                          className="text-red-400 hover:text-red-600 p-1"
                        >
                          <i className="fas fa-times"></i>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-100 flex gap-4">
            <button 
              type="submit"
              disabled={isSaving || isUploading}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold py-4 px-6 rounded-xl shadow-lg shadow-green-500/20 transition-all flex items-center justify-center gap-2 disabled:bg-slate-400"
            >
              {isSaving ? <i className="fas fa-circle-notch fa-spin"></i> : <i className="fas fa-save"></i>}
              Finalizar e Salvar Lançamento
            </button>
            <button 
              type="button"
              onClick={() => navigate('/dashboard')}
              className="px-6 py-4 border border-slate-300 text-slate-600 font-bold rounded-xl hover:bg-slate-50 transition-all"
            >
              Manter Reservado
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default FormDocumento;
