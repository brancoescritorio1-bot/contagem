
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function summarizeDemand(demand: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Resuma a seguinte demanda administrativa para um campo de "Assunto" curto (máximo 10 palavras): "${demand}"`,
    });
    return response.text || demand;
  } catch (error) {
    console.error("Gemini Error:", error);
    return demand;
  }
}

export async function suggestRecipientFormalGreeting(recipient: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Gere uma saudação formal curta para um documento endereçado a: "${recipient}"`,
    });
    return response.text || `Prezado(a) ${recipient},`;
  } catch (error) {
    return `Prezado(a) ${recipient},`;
  }
}
