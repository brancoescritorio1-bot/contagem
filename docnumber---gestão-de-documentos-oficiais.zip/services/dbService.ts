
import { DocumentRecord, DocumentTypeConfig, DocumentStatus, User, UserRole } from '../types';

const INITIAL_TYPES: DocumentTypeConfig[] = [
  { id: '1', sigla: 'CE', descricao: 'Comunicação Externa', prefixo: 'GMNL', contadorAtual: 1, resetAnual: true },
  { id: '2', sigla: 'CI', descricao: 'Comunicação Interna', prefixo: 'GMNL', contadorAtual: 1, resetAnual: true },
  { id: '3', sigla: 'OF', descricao: 'Ofício', prefixo: 'GMNL', contadorAtual: 1, resetAnual: true },
];

const INITIAL_USERS: User[] = [
  { id: 'admin-1', nome: 'Administrador GMNL', email: 'admin@gmnl.com', perfil: UserRole.ADMIN },
  { id: 'user-1', nome: 'Lara Silva', email: 'lara@gmnl.com', perfil: UserRole.USER },
];

class DatabaseService {
  private users: User[] = [...INITIAL_USERS];
  private documentTypes: DocumentTypeConfig[] = [...INITIAL_TYPES];
  private documents: DocumentRecord[] = [];

  constructor() {
    this.loadFromStorage();
  }

  private loadFromStorage() {
    const data = localStorage.getItem('docnumber_db');
    if (data) {
      const parsed = JSON.parse(data);
      this.documentTypes = parsed.documentTypes || INITIAL_TYPES;
      this.documents = parsed.documents || [];
      this.users = parsed.users || INITIAL_USERS;
    }
  }

  private persist() {
    localStorage.setItem('docnumber_db', JSON.stringify({
      documentTypes: this.documentTypes,
      documents: this.documents,
      users: this.users
    }));
    window.dispatchEvent(new Event('db_updated'));
  }

  getUsers() { 
    this.loadFromStorage();
    return this.users; 
  }

  addUser(user: Omit<User, 'id'>) {
    const newUser = { ...user, id: Math.random().toString(36).substr(2, 9) };
    this.users.push(newUser);
    this.persist();
    return newUser;
  }

  deleteUser(id: string) {
    this.users = this.users.filter(u => u.id !== id);
    this.persist();
  }
  
  getDocumentTypes() { 
    this.loadFromStorage();
    return this.documentTypes; 
  }

  getDocuments() { 
    this.loadFromStorage();
    return this.documents; 
  }

  addDocumentType(config: Omit<DocumentTypeConfig, 'id'>) {
    const newType = { ...config, id: Math.random().toString(36).substr(2, 9) };
    this.documentTypes.push(newType);
    this.persist();
    return newType;
  }

  updateDocumentType(id: string, updates: Partial<DocumentTypeConfig>) {
    this.documentTypes = this.documentTypes.map(t => t.id === id ? { ...t, ...updates } : t);
    this.persist();
  }

  reserveNumber(typeId: string, user: User): DocumentRecord {
    this.loadFromStorage();
    const typeIdx = this.documentTypes.findIndex(t => t.id === typeId);
    if (typeIdx === -1) throw new Error("Tipo de documento não encontrado");

    const type = this.documentTypes[typeIdx];
    const currentYear = new Date().getFullYear();
    let nextNumber = type.contadorAtual;
    
    if (type.resetAnual && type.lastYearReset !== currentYear) {
      nextNumber = 1;
      this.documentTypes[typeIdx].lastYearReset = currentYear;
    }

    const paddedNumber = nextNumber.toString().padStart(3, '0');
    const codigoCompleto = `${type.sigla} ${type.prefixo} ${paddedNumber}/${currentYear}`;

    this.documentTypes[typeIdx].contadorAtual = nextNumber + 1;

    const newDoc: DocumentRecord = {
      id: Math.random().toString(36).substr(2, 9),
      tipo: type.sigla,
      prefixo: type.prefixo,
      numero: paddedNumber,
      ano: currentYear.toString(),
      codigoCompleto,
      usuarioId: user.id,
      usuarioNome: user.nome,
      demandaSolicitante: '',
      impactado: '',
      destinatario: '',
      dataEnvio: new Date().toISOString().split('T')[0],
      status: DocumentStatus.RESERVADO,
      anexos: [],
      createdAt: new Date().toISOString()
    };

    this.documents.push(newDoc);
    this.persist();
    return newDoc;
  }

  updateDocument(id: string, updates: Partial<DocumentRecord>) {
    this.documents = this.documents.map(doc => doc.id === id ? { ...doc, ...updates } : doc);
    this.persist();
  }

  getDocumentById(id: string) {
    this.loadFromStorage();
    return this.documents.find(doc => doc.id === id);
  }
}

export const dbService = new DatabaseService();
