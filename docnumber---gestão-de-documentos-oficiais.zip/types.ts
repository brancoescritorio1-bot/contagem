
export enum UserRole {
  USER = 'usuario',
  ADMIN = 'admin'
}

export enum DocumentStatus {
  RESERVADO = 'Reservado',
  LANCADO = 'Lançado'
}

export interface User {
  id: string;
  nome: string;
  email: string;
  perfil: UserRole;
}

export interface DocumentTypeConfig {
  id: string;
  sigla: string;
  descricao: string;
  prefixo: string;
  contadorAtual: number;
  resetAnual: boolean;
  lastYearReset?: number;
}

export interface DocumentRecord {
  id: string;
  tipo: string;
  prefixo: string;
  numero: string;
  ano: string;
  codigoCompleto: string;
  usuarioId: string;
  usuarioNome: string;
  demandaSolicitante: string;
  impactado: string;
  destinatario: string;
  dataEnvio: string;
  status: DocumentStatus;
  anexos: string[];
  createdAt: string;
}

export interface AppState {
  currentUser: User | null;
  documents: DocumentRecord[];
  documentTypes: DocumentTypeConfig[];
}
